
//Q-2-
package com.task;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.PriorityQueue;

class LogEntry implements Comparable<LogEntry> {
    private String id;
    private LocalDateTime datetime;

    public LogEntry(String jobid, LocalDateTime time) {
        this.id = jobid;
        this.datetime = time;
    }

    public String getJobId() {
        return id;
    }

    public LocalDateTime getTimestamp() {
        return datetime;
    }

    @Override
    public int compareTo(LogEntry other) {
        return datetime.compareTo(other.datetime);
    }
}

public class DateTime {
    public static void main(String[] args) {
        DateTimeFormatter datetime = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        PriorityQueue<LogEntry> queue = new PriorityQueue<>();

        queue.add(new LogEntry("J1", LocalDateTime.parse("2023-06-29 04:01:01", datetime)));
        queue.add(new LogEntry("J2", LocalDateTime.parse("2023-06-29 04:02:02", datetime)));
        queue.add(new LogEntry("J1", LocalDateTime.parse("2023-06-29 04:03:03", datetime)));
        queue.add(new LogEntry("J3", LocalDateTime.parse("2023-06-29 04:04:04", datetime)));
        queue.add(new LogEntry("J1", LocalDateTime.parse("2023-06-29 04:05:05", datetime)));

        LocalDateTime timeformat = LocalDateTime.parse("2023-06-29 04:04:04", datetime);

        String findTime = findFirstLogJ1AfterTimestamp(queue, timeformat);

        System.out.println("First log of J1 after " + timeformat + ": " + findTime);
    }

    private static String findFirstLogJ1AfterTimestamp(PriorityQueue<LogEntry> queue, LocalDateTime time) {
        while (!queue.isEmpty()) {
            LogEntry logEntry = queue.poll();
            if (logEntry.getJobId().equals("J1") && logEntry.getTimestamp().isAfter(time)) {
                return logEntry.getJobId();
            }
        }
        return "None";
    }
}
