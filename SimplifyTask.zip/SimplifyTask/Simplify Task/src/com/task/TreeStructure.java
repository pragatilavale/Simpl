//Q-1

package com.task;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class Node {
    String name;
    List<Node> children;

    public Node(String name) {
        this.name = name;
        this.children = new ArrayList<>();
    }

    public void addChild(Node child) {
        children.add(child);
    }
}

class graph {
    private Map<String, Node> nodes;
    private Map<String, String> flowerToBouquet;

    public graph() {
        nodes = new HashMap<>();
        flowerToBouquet = new HashMap<>();
    }

    public void addNode(String name) {
        if (!nodes.containsKey(name)) {
            nodes.put(name, new Node(name));
        }
    }

    public void addEdge(String parent, String child) {
        if (nodes.containsKey(parent) && nodes.containsKey(child)) {
            Node parentNode = nodes.get(parent);
            Node childNode = nodes.get(child);
            parentNode.addChild(childNode);
        }
    }

    public void addFlowerToBouquet(String flower, String bouquet) {
        flowerToBouquet.put(flower, bouquet);
    }

    public String lookupBouquet(String flower) {
        return flowerToBouquet.getOrDefault(flower, "None");
    }
}

public class TreeStructure {
    public static void main(String[] args) {        
    	
    	graph BG = new graph();

    	BG.addNode("bouquet1");
    	BG.addNode("bouquet2");
    	BG.addNode("bouquet3");
    	BG.addNode("bouquet4");
    	BG.addNode("bouquet5");

    	BG.addEdge("bouquet1", "bouquet2");
    	BG.addEdge("bouquet1", "bouquet3");
    	BG.addEdge("bouquet2", "bouquet4");
    	BG.addEdge("bouquet3", "bouquet5");

    	BG.addFlowerToBouquet("Red Rose", "bouquet1");

        String flower = "Red Rose";
        String flower1 = "Pink Lily";
        String bouquet = BG.lookupBouquet(flower);
        String bouquet1 = BG.lookupBouquet(flower1);
        System.out.println("Flower: " + flower);
        System.out.println("Output: " + bouquet);
        System.out.println("*********************");
        System.out.println("Flower: " + flower1);
        System.out.println("Output: " + bouquet1);
    }
}
